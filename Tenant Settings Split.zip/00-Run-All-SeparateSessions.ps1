
<#
.SYNOPSIS
    Launcher that starts each tenant export workload in a separate PowerShell process.
.DESCRIPTION
    Use this only when you want to guide the customer through each workload. Each child script opens in a fresh process and can use different credentials.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)][string]$TenantName,
    [Parameter(Mandatory=$false)][string]$SPOAdminUrl,
    [Parameter(Mandatory=$false)][string]$OutputRoot = "$env:USERPROFILE\Desktop\M365TenantExport_Split",
    [Parameter(Mandatory=$false)][switch]$SkipModuleInstall,
    [Parameter(Mandatory=$false)][switch]$IncludeMicrosoft365DSC
)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$pwsh = (Get-Command pwsh.exe -ErrorAction SilentlyContinue).Source
if (-not $pwsh) { $pwsh = (Get-Command powershell.exe -ErrorAction SilentlyContinue).Source }
if (-not $pwsh) { throw 'No PowerShell executable found.' }

$scripts = @(
    '01-GeneralGraph-EntraID-Export.ps1',
    '02-ExchangeOnline-Defender-Export.ps1',
    '03-SharePointOnline-Export.ps1',
    '04-Teams-Export.ps1',
    '05-PurviewCompliance-Export.ps1',
    '06-IntuneGraph-Export.ps1',
    '07-PowerPlatform-Export.ps1'
)
if ($IncludeMicrosoft365DSC) { $scripts += '08-Microsoft365DSC-Export.ps1' }

foreach ($s in $scripts) {
    $path = Join-Path $here $s
    if (-not (Test-Path $path)) { Write-Warning "Missing script: $path"; continue }
    $argsList = @('-NoExit','-ExecutionPolicy','Bypass','-File',"`"$path`"",'-OutputRoot',"`"$OutputRoot`"")
    #if ($TenantName) { $argsList += @('-TenantName',"`"$TenantName`"") } #$TenantName for EntraID Only
    #if ($SPOAdminUrl) { $argsList += @('-SPOAdminUrl',"`"$SPOAdminUrl`"") } #$SPOAdminUrl for SharePoint Online Only
    if ($SkipModuleInstall) { $argsList += '-SkipModuleInstall' }
    Write-Host "Starting separate PowerShell session: $s" -ForegroundColor Cyan
    Start-Process -FilePath $pwsh -ArgumentList ($argsList -join ' ') -Wait
}
