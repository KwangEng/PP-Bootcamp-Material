
# Common helper functions embedded in each workload script
[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)][string]$TenantName,
    [Parameter(Mandatory=$false)][string]$OutputRoot = "$env:USERPROFILE\Desktop\M365TenantExport_Split",
    [Parameter(Mandatory=$false)][switch]$SkipModuleInstall
)

#if needed
#$MaximumFunctionCount = 32768
#$MaximumVariableCount = 32768

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$ScriptName = [IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Name)
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$BasePath = Join-Path $OutputRoot $ScriptName
$RunPath = Join-Path $BasePath $timestamp
$LogPath = Join-Path $RunPath '_Logs'
$Summary = New-Object System.Collections.Generic.List[object]

function New-Folder { param([string]$Path) if (-not (Test-Path $Path)) { New-Item -Path $Path -ItemType Directory -Force | Out-Null } }
function Write-Status { param([string]$Message,[string]$Level='INFO') $line="[{0}] [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Level,$Message; Write-Host $line; Add-Content -Path (Join-Path $LogPath 'run.log') -Value $line -Encoding UTF8 }
function Add-Summary { param([string]$Workload,[string]$Name,[string]$Status,[string]$Detail,[string]$Path) $Summary.Add([pscustomobject]@{Time=Get-Date -Format 'yyyy-MM-dd HH:mm:ss';Workload=$Workload;Name=$Name;Status=$Status;Detail=$Detail;Path=$Path}) | Out-Null }
function Ensure-Module { param([string]$Name) if(Get-Module -ListAvailable -Name $Name){Write-Status "Module available: $Name"; return}; if($SkipModuleInstall){Write-Status "Module missing and install skipped: $Name" 'WARN'; return}; try{Write-Status "Installing module: $Name"; Install-Module -Name $Name -Scope CurrentUser -Force -AllowClobber}catch{Write-Status "Failed to install $Name. $($_.Exception.Message)" 'ERROR'} }
function ConvertTo-SafeFileName { param([string]$Name) if([string]::IsNullOrWhiteSpace($Name)){return 'Unnamed'}; return ($Name -replace '[\\/:*?"<>|]','_' -replace '\s+','_') }
function Export-Data { param($Data,[string]$Folder,[string]$Name,[string]$Workload='General') New-Folder $Folder; $safe=ConvertTo-SafeFileName $Name; $json=Join-Path $Folder "$safe.json"; $csv=Join-Path $Folder "$safe.csv"; try{ $Data | ConvertTo-Json -Depth 100 | Out-File -FilePath $json -Encoding UTF8; try{$Data | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8}catch{}; $count=@($Data).Count; Add-Summary $Workload $Name 'Success' "Exported $count object(s)" $json; Write-Status "Exported $Workload - $Name ($count object(s))" }catch{Add-Summary $Workload $Name 'Failed' $_.Exception.Message $json; Write-Status "Failed export $Workload - $Name. $($_.Exception.Message)" 'ERROR'} }
function Invoke-ExportCommand { param([string]$Workload,[string]$Name,[string]$Folder,[scriptblock]$Command) try{Write-Status "Collecting $Workload - $Name"; $data=& $Command; if($null -eq $data){Add-Summary $Workload $Name 'NoData' 'Command returned no data' ''; Write-Status "No data for $Workload - $Name" 'WARN'} else {Export-Data $data $Folder $Name $Workload}}catch{Add-Summary $Workload $Name 'Failed' $_.Exception.Message ''; Write-Status "Failed $Workload - $Name. $($_.Exception.Message)" 'ERROR'} }
function Invoke-IfCmdletExists { param([string]$Cmdlet,[string]$Workload,[string]$Name,[string]$Folder,[scriptblock]$Command) if(Get-Command $Cmdlet -ErrorAction SilentlyContinue){Invoke-ExportCommand $Workload $Name $Folder $Command}else{Add-Summary $Workload $Name 'Skipped' "Cmdlet not available: $Cmdlet" ''; Write-Status "Skipped $Workload - $Name. Cmdlet not available: $Cmdlet" 'WARN'} }
function Invoke-GraphExport { param([string]$Workload,[string]$Name,[string]$Folder,[string]$Uri) Invoke-ExportCommand $Workload $Name $Folder { $items=New-Object System.Collections.Generic.List[object]; $next=$Uri; do { $r=Invoke-MgGraphRequest -Method GET -Uri $next -ErrorAction Stop; if($r.value){foreach($v in $r.value){$items.Add($v)|Out-Null}} else {$items.Add($r)|Out-Null}; $next=$r.'@odata.nextLink' } while($next); $items } }
function Save-Summary { $Summary | Export-Csv -Path (Join-Path $RunPath 'ExportSummary.csv') -NoTypeInformation -Encoding UTF8; $Summary | ConvertTo-Json -Depth 20 | Out-File -FilePath (Join-Path $RunPath 'ExportSummary.json') -Encoding UTF8; Write-Status "Summary saved to $RunPath" }

New-Folder $RunPath; New-Folder $LogPath
Start-Transcript -Path (Join-Path $LogPath 'transcript.txt') -Force | Out-Null
Write-Status "Starting $ScriptName. Output folder: $RunPath"

Ensure-Module Microsoft.Graph
Import-Module Microsoft.Graph -ErrorAction SilentlyContinue
$folder = Join-Path $RunPath 'GeneralGraph_EntraID'
New-Folder $folder

# Connection scopes
$GraphScopes = @(
    'Organization.Read.All','Directory.Read.All','Domain.Read.All','Policy.Read.All','RoleManagement.Read.Directory',
    'Application.Read.All','User.Read.All','Group.Read.All','AuditLog.Read.All','IdentityProvider.Read.All',
    'EntitlementManagement.Read.All','PrivilegedAccess.Read.AzureAD','DeviceManagementConfiguration.Read.All',
    'DeviceManagementApps.Read.All','DeviceManagementManagedDevices.Read.All','SecurityEvents.Read.All',
    'ThreatHunting.Read.All','Reports.Read.All','MultiTenantOrganization.Read.All'
)

try {
    Write-Status 'Connecting to Microsoft Graph'
    if ($TenantName) { Connect-MgGraph -TenantId $TenantName -Scopes $GraphScopes -NoWelcome }
    else { Connect-MgGraph -Scopes $GraphScopes -NoWelcome }
    $ctx = Get-MgContext
    Export-Data -Data $ctx -Folder $Folders['General'] -Name 'GraphContext' -Workload 'General'
} catch { Write-Status "Graph connection failed. $($_.Exception.Message)" 'ERROR' }

# General tenant / licensing / domains
Invoke-IfCmdletExists Get-MgOrganization 'GeneralGraph_EntraID' 'Organization' $folder { Get-MgOrganization -Property * }
Invoke-IfCmdletExists Get-MgSubscribedSku 'GeneralGraph_EntraID' 'SubscribedSKUs' $folder { Get-MgSubscribedSku -All }
Invoke-IfCmdletExists Get-MgDomain 'GeneralGraph_EntraID' 'Domains' $folder { Get-MgDomain -All }
Invoke-IfCmdletExists Get-MgDirectoryRole 'GeneralGraph_EntraID' 'DirectoryRoles' $folder { Get-MgDirectoryRole -All }
Invoke-IfCmdletExists Get-MgDirectoryRoleTemplate 'GeneralGraph_EntraID' 'DirectoryRoleTemplates' $folder { Get-MgDirectoryRoleTemplate -All }

# Entra ID via Graph cmdlets
Invoke-IfCmdletExists Get-MgPolicyAuthorizationPolicy 'GeneralGraph_EntraID' 'AuthorizationPolicy' $folder { Get-MgPolicyAuthorizationPolicy }
Invoke-IfCmdletExists Get-MgPolicyAuthenticationMethodPolicy 'GeneralGraph_EntraID' 'AuthenticationMethodPolicy' $folder { Get-MgPolicyAuthenticationMethodPolicy }
Invoke-IfCmdletExists Get-MgIdentityConditionalAccessPolicy 'GeneralGraph_EntraID' 'ConditionalAccessPolicies' $folder { Get-MgIdentityConditionalAccessPolicy -All }
Invoke-IfCmdletExists Get-MgIdentityConditionalAccessNamedLocation 'GeneralGraph_EntraID' 'ConditionalAccessNamedLocations' $folder { Get-MgIdentityConditionalAccessNamedLocation -All }
Invoke-IfCmdletExists Get-MgPolicyCrossTenantAccessPolicy 'GeneralGraph_EntraID' 'CrossTenantAccessPolicy' $folder { Get-MgPolicyCrossTenantAccessPolicy }
Invoke-IfCmdletExists Get-MgPolicyCrossTenantAccessPolicyDefault 'GeneralGraph_EntraID' 'CrossTenantAccessPolicyDefault' $folder { Get-MgPolicyCrossTenantAccessPolicyDefault }
Invoke-IfCmdletExists Get-MgPolicyCrossTenantAccessPolicyPartner 'GeneralGraph_EntraID' 'CrossTenantAccessPolicyPartners' $folder { Get-MgPolicyCrossTenantAccessPolicyPartner -All }
Invoke-IfCmdletExists Get-MgPolicyIdentitySecurityDefaultEnforcementPolicy 'GeneralGraph_EntraID' 'SecurityDefaults' $folder { Get-MgPolicyIdentitySecurityDefaultEnforcementPolicy }
Invoke-IfCmdletExists Get-MgDirectoryAdministrativeUnit 'GeneralGraph_EntraID' 'AdministrativeUnits' $folder { Get-MgDirectoryAdministrativeUnit -All }
Invoke-IfCmdletExists Get-MgServicePrincipal 'GeneralGraph_EntraID' 'ServicePrincipals' $folder { Get-MgServicePrincipal -All -Property Id,AppId,DisplayName,AccountEnabled,AppOwnerOrganizationId,PublisherName,SignInAudience,ServicePrincipalType,Tags,CreatedDateTime }
Invoke-IfCmdletExists Get-MgApplication 'GeneralGraph_EntraID' 'Applications' $folder { Get-MgApplication -All -Property Id,AppId,DisplayName,SignInAudience,PublisherDomain,CreatedDateTime,RequiredResourceAccess,Web,Spa,PublicClient,Api }
#Invoke-IfCmdletExists Get-MgGroup 'GeneralGraph_EntraID' 'Groups' $folder { Get-MgGroup -All -Property Id,DisplayName,Mail,MailEnabled,SecurityEnabled,GroupTypes,Visibility,CreatedDateTime }
#Invoke-IfCmdletExists Get-MgUser 'GeneralGraph_EntraID' 'Users_BasicInventory' $folder { Get-MgUser -All -Property Id,DisplayName,UserPrincipalName,AccountEnabled,UserType,CreatedDateTime,Department,JobTitle,OnPremisesSyncEnabled }
#Invoke-IfCmdletExists Get-MgDevice 'GeneralGraph_EntraID' 'Devices' $folder { Get-MgDevice -All -Property Id,DisplayName,AccountEnabled,OperatingSystem,OperatingSystemVersion,TrustType,ApproximateLastSignInDateTime,IsCompliant,IsManaged }

if(Get-Command Invoke-MgGraphRequest -ErrorAction SilentlyContinue){
    Invoke-GraphExport 'GeneralGraph_EntraID' 'DirectorySettings' $folder '/v1.0/settings'
    Invoke-GraphExport 'GeneralGraph_EntraID' 'IdentityProviders' $folder '/v1.0/identity/identityProviders'
    Invoke-GraphExport 'GeneralGraph_EntraID' 'AccessPackageCatalogs' $folder '/v1.0/identityGovernance/entitlementManagement/catalogs'
    Invoke-GraphExport 'GeneralGraph_EntraID' 'AccessPackages' $folder '/v1.0/identityGovernance/entitlementManagement/accessPackages'
    Invoke-GraphExport 'GeneralGraph_EntraID' 'TermsOfUse' $folder '/v1.0/identityGovernance/termsOfUse/agreements'
}
Save-Summary
try{Disconnect-MgGraph -ErrorAction SilentlyContinue}catch{}
Stop-Transcript | Out-Null
