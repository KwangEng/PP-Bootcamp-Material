
# Common helper functions embedded in each workload script
[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)][string]$OutputRoot = "$env:USERPROFILE\Desktop\M365TenantExport_Split",
    [Parameter(Mandatory=$false)][switch]$SkipModuleInstall
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$ScriptName = [IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Name)
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$BasePath = Join-Path $OutputRoot $ScriptName
$RunPath = Join-Path $BasePath $timestamp
$LogPath = Join-Path $RunPath '_Logs'
$Summary = New-Object System.Collections.Generic.List[object]

function New-Folder { param([string]$Path) if (-not (Test-Path $Path)) { New-Item -Path $Path -ItemType Directory -Force | Out-Null } }
function Write-Status { param([string]$Message,[string]$Level='INFO') $line="[{0}] [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Level,$Message; Write-Host $line; Add-Content -Path (Join-Path $LogPath 'run.log') -Value $line -Encoding UTF8 }
function Add-Summary { param([string]$Workload,[string]$Name,[string]$Status,[string]$Detail,[string]$Path) $Summary.Add([pscustomobject]@{Time=Get-Date -Format 'yyyy-MM-dd HH:mm:ss';Workload=$Workload;Name=$Name;Status=$Status;Detail=$Detail;Path=$Path}) | Out-Null }
function Ensure-Module { param([string]$Name) if(Get-Module -ListAvailable -Name $Name){Write-Status "Module available: $Name"; return}; if($SkipModuleInstall){Write-Status "Module missing and install skipped: $Name" 'WARN'; return}; try{Write-Status "Installing module: $Name"; Install-Module -Name $Name -Scope CurrentUser -Force -AllowClobber}catch{Write-Status "Failed to install $Name. $($_.Exception.Message)" 'ERROR'} }
function ConvertTo-SafeFileName { param([string]$Name) if([string]::IsNullOrWhiteSpace($Name)){return 'Unnamed'}; return ($Name -replace '[\\/:*?"<>|]','_' -replace '\s+','_') }
function Export-Data { param($Data,[string]$Folder,[string]$Name,[string]$Workload='General') New-Folder $Folder; $safe=ConvertTo-SafeFileName $Name; $json=Join-Path $Folder "$safe.json"; $csv=Join-Path $Folder "$safe.csv"; try{ $Data | ConvertTo-Json -Depth 100 | Out-File -FilePath $json -Encoding UTF8; try{$Data | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8}catch{}; $count=@($Data).Count; Add-Summary $Workload $Name 'Success' "Exported $count object(s)" $json; Write-Status "Exported $Workload - $Name ($count object(s))" }catch{Add-Summary $Workload $Name 'Failed' $_.Exception.Message $json; Write-Status "Failed export $Workload - $Name. $($_.Exception.Message)" 'ERROR'} }
function Invoke-ExportCommand { param([string]$Workload,[string]$Name,[string]$Folder,[scriptblock]$Command) try{Write-Status "Collecting $Workload - $Name"; $data=& $Command; if($null -eq $data){Add-Summary $Workload $Name 'NoData' 'Command returned no data' ''; Write-Status "No data for $Workload - $Name" 'WARN'} else {Export-Data $data $Folder $Name $Workload}}catch{Add-Summary $Workload $Name 'Failed' $_.Exception.Message ''; Write-Status "Failed $Workload - $Name. $($_.Exception.Message)" 'ERROR'} }
function Invoke-IfCmdletExists { param([string]$Cmdlet,[string]$Workload,[string]$Name,[string]$Folder,[scriptblock]$Command) if(Get-Command $Cmdlet -ErrorAction SilentlyContinue){Invoke-ExportCommand $Workload $Name $Folder $Command}else{Add-Summary $Workload $Name 'Skipped' "Cmdlet not available: $Cmdlet" ''; Write-Status "Skipped $Workload - $Name. Cmdlet not available: $Cmdlet" 'WARN'} }
function Invoke-GraphExport { param([string]$Workload,[string]$Name,[string]$Folder,[string]$Uri) Invoke-ExportCommand $Workload $Name $Folder { $items=New-Object System.Collections.Generic.List[object]; $next=$Uri; do { $r=Invoke-MgGraphRequest -Method GET -Uri $next -ErrorAction Stop; if($r.value){foreach($v in $r.value){$items.Add($v)|Out-Null}} else {$items.Add($r)|Out-Null}; $next=$r.'@odata.nextLink' } while($next); $items } }
function Save-Summary { $Summary | Export-Csv -Path (Join-Path $RunPath 'ExportSummary.csv') -NoTypeInformation -Encoding UTF8; $Summary | ConvertTo-Json -Depth 20 | Out-File -FilePath (Join-Path $RunPath 'ExportSummary.json') -Encoding UTF8; Write-Status "Summary saved to $RunPath" }

New-Folder $RunPath; New-Folder $LogPath
Start-Transcript -Path (Join-Path $LogPath 'transcript.txt') -Force | Out-Null
Write-Status "Starting $ScriptName. Output folder: $RunPath"

Ensure-Module Microsoft.PowerApps.Administration.PowerShell
Ensure-Module Microsoft.PowerApps.PowerShell
Import-Module Microsoft.PowerApps.Administration.PowerShell -ErrorAction SilentlyContinue
Import-Module Microsoft.PowerApps.PowerShell -ErrorAction SilentlyContinue
$folder = Join-Path $RunPath 'PowerPlatform'
New-Folder $folder
try { Add-PowerAppsAccount | Out-Null } catch { Write-Status "Power Platform connection failed. $($_.Exception.Message)" 'ERROR' }
$cmds = @('Get-TenantSettings','Get-AdminPowerAppEnvironment','Get-AdminPowerApp','Get-AdminFlow','Get-AdminPowerAppConnector','Get-AdminDlpPolicy','Get-AdminPowerAppConnection','Get-AdminPowerAppConnectorRoleAssignment','Get-AdminPowerAppRoleAssignment')
foreach($cmd in $cmds){ Invoke-IfCmdletExists $cmd 'PowerPlatform' $cmd $folder ([scriptblock]::Create("$cmd | Select-Object *")) }
Save-Summary
Stop-Transcript | Out-Null
