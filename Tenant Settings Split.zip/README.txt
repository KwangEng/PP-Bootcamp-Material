
M365 Tenant Export Split Scripts
================================

Purpose
-------
These scripts split Microsoft 365 tenant export by workload so each workload runs in a separate PowerShell process and can authenticate with a different credential.

Recommended execution order
---------------------------
1. 01-GeneralGraph-EntraID-Export.ps1
2. 02-ExchangeOnline-Defender-Export.ps1
3. 03-SharePointOnline-Export.ps1
4. 04-Teams-Export.ps1 (Connect-MicrosoftTeams cannot run under PowerShell ISE)
5. 05-PurviewCompliance-Export.ps1
6. 06-IntuneGraph-Export.ps1
7. 07-PowerPlatform-Export.ps1
8. 08-Microsoft365DSC-Export.ps1 optional baseline snapshot

Example manual runs
-------------------
PowerShell -ExecutionPolicy Bypass -File .\01-GeneralGraph-EntraID-Export.ps1 -TenantName contoso.onmicrosoft.com
PowerShell -ExecutionPolicy Bypass -File .\02-ExchangeOnline-Defender-Export.ps1
PowerShell -ExecutionPolicy Bypass -File .\03-SharePointOnline-Export.ps1 -SPOAdminUrl https://contoso-admin.sharepoint.com
PowerShell -ExecutionPolicy Bypass -File .\07-PowerPlatform-Export.ps1

Example launcher
----------------
PowerShell -ExecutionPolicy Bypass -File .\00-Run-All-SeparateSessions.ps1 -TenantName contoso.onmicrosoft.com -SPOAdminUrl https://contoso-admin.sharepoint.com

Output
------
Each script creates a timestamped folder under:
%USERPROFILE%\Desktop\M365TenantExport_Split\<ScriptName>\<yyyyMMdd_HHmmss>

Each run contains:
- JSON files: detail and nested object source of truth
- CSV files: easy review where PowerShell can flatten the object
- ExportSummary.csv and ExportSummary.json
- _Logs\run.log and _Logs\transcript.txt

Notes
-----
- Scripts are read-only except module installation and authentication/session setup.
- Use -SkipModuleInstall if the customer environment blocks Install-Module.
- Different credentials can be used for each workload because every script runs independently.
- If a cmdlet is not available or roles are insufficient, the item is logged as Skipped or Failed in ExportSummary.csv.
